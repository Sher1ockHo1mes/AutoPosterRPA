import xbot
import xbot_visual
from . import package
from .package import variables as glv
import time

def main(args):
    try:
        dialogResult = xbot_visual.dialog.show_custom_dialog(settings="{\"dialogTitle\":\"欢迎来到破局行动RPA+Agent赛道\",\"height\":30,\"width\":0,\"timeout\":600,\"autoCloseButton\":\"取消\",\"use_wait_timeout\":true,\"canRememberContent\":true,\"settings\":{\"editors\":[{\"type\":\"Label\",\"value\":\"欢迎来到破局行动RPA+Agent赛道\",\"fontFamily\":\"Microsoft YaHei UI\",\"fontSize\":12,\"label\":null},{\"type\":\"File\",\"label\":\"读取Excel位置\",\"VariableName\":\"excelPath\",\"kind\":0,\"filter\":\"所有文件|*.*\",\"value\":null,\"nullText\":\"请选择路径\"},{\"type\":\"File\",\"label\":\"下载图片地址\",\"VariableName\":\"ImageSavePath\",\"kind\":0,\"filter\":\"所有文件|*.*\",\"value\":\"D:\\\\GPTImage\",\"nullText\":\"请选择保存图片的文件夹\"}],\"buttons\":[{\"type\":\"Button\",\"label\":\"确定\",\"theme\":\"white\",\"hotKey\":\"Return\"},{\"type\":\"Button\",\"label\":\"取消\",\"theme\":\"white\",\"hotKey\":\"Escape\"}]}}", dialog_title="欢迎来到破局行动RPA+Agent赛道", default_btn="确定", is_auto_click=False, timeout=None, globals=globals(), locals=locals(), storage_key="ec0a3205-a172-4c0b-9b1b-dcc70bed3c62", _block=("main", 1, "打开自定义对话框"))
        ImageSavePath = xbot_visual.programing.variable(value=dialogResult.ImageSavePath
        , _block=("main", 2, "设置变量"))
        xbot_visual.programing.log(type="info", text=ImageSavePath, _block=("main", 3, "打印日志"))
        ImageSavePath = xbot_visual.file.get_file_parts(path=ImageSavePath, _block=("main", 4, "获取文件路径信息"))
        xbot_visual.programing.log(type="info", text=ImageSavePath.directory, _block=("main", 5, "打印日志"))
        coze网页海报bot = xbot_visual.web.create(web_type="chrome", value="https://www.coze.cn/store/agent/7426224398489239587?bid=6e63fer58601i&bot_id=true", silent_running=True, wait_load_completed=True, load_timeout="20", stop_load_if_load_timeout="handleExcept", chrome_file_name=None, edge_file_name=None, ie_file_name=None, bro360_file_name=None, firefox_file_name=None, arguments=None, _block=("main", 6, "打开网页"))
        xbot_visual.web.browser.wait_load_completed(browser=coze网页海报bot, load_timeout="20", action_after_load_timeout="handleExcept", _block=("main", 7, "等待网页加载完成"))
        打开的Excel对象 = xbot_visual.excel.launch(launch_way="open", driver_way="wps", open_filename=dialogResult.excelPath, save_filename="", isvisible=False, ignoreformula=False, password=None, write_password=None, update_links=True, _block=("main", 8, "打开/新建Excel"))
        excel数据 = xbot_visual.excel.read_data_from_workbook(workbook=打开的Excel对象, read_way="used_range", range=None, cell_row_num=None, cell_column_name=None, area_begin_row_num=None, area_begin_column_name=None, area_end_row_num=None, area_end_column_name=None, row_row_num=None, get_display_text=False, has_header_row=False, column_column_name=None, sheet_name="", using_text=False, text_cols="", clear_space=False, _block=("main", 9, "读取Excel内容"))
        xbot_visual.programing.log(type="info", text=excel数据, _block=("main", 10, "打印日志"))
        for 列表循环当前位置, 列表循环当前项 in enumerate(xbot_visual.workflow.list_iterator(list=excel数据, loop_start_index="1", loop_end_index="-1", output_with_index=True, _block=("main", 11, "ForEach列表循环"))):
            xbot_visual.web.element.click(browser=coze网页海报bot, element=package.selector("coze网页自定义背景"), simulate=True, move_mouse=False, clicks="click", button="left", keys="null", delay_after="1", anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", timeout="20", _block=("main", 12, "点击元素(web)"))
            xbot_visual.web.element.input(browser=coze网页海报bot, element=package.selector("coze自定义背景num"), text=lambda: 列表循环当前项[2], append=False, simulate=True, driver_input=False, save_to_clipboard=False, input_type="simulate", contains_hotkey=False, force_ime_ENG=False, send_key_delay="5", focus_timeout="1000", delay_after="0", click_before_input=True, anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", timeout="20", _block=("main", 13, "填写输入框(web)"))
            xbot_visual.web.element.input(browser=coze网页海报bot, element=package.selector("coze自定义背景title"), text=lambda: 列表循环当前项[0], append=False, simulate=True, driver_input=False, save_to_clipboard=False, input_type="simulate", contains_hotkey=False, force_ime_ENG=False, send_key_delay="5", focus_timeout="1000", delay_after="0", click_before_input=True, anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", timeout="20", _block=("main", 14, "填写输入框(web)"))
            xbot_visual.web.element.input(browser=coze网页海报bot, element=package.selector("coze自定义背景content"), text=lambda: 列表循环当前项[1], append=False, simulate=True, driver_input=False, save_to_clipboard=False, input_type="simulate", contains_hotkey=False, force_ime_ENG=False, send_key_delay="5", focus_timeout="1000", delay_after="0", click_before_input=True, anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", timeout="20", _block=("main", 15, "填写输入框(web)"))
            if xbot_visual.workflow.test(operand1=lambda: 列表循环当前项[3], operator="in", operand2="否", operator_options="{\"ignoreCase\":\"False\"}", _block=("main", 16, "IF 条件")):
                xbot_visual.web.element.click(browser=coze网页海报bot, element=package.selector("是否原创下拉框"), simulate=True, move_mouse=False, clicks="click", button="left", keys="null", delay_after="1", anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", timeout="20", _block=("main", 17, "点击元素(web)"))
                xbot_visual.web.element.click(browser=coze网页海报bot, element=package.selector("自定义背景是否原创-否"), simulate=True, move_mouse=False, clicks="click", button="left", keys="null", delay_after="1", anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", timeout="20", _block=("main", 18, "点击元素(web)"))
            #endif
            xbot_visual.web.element.click(browser=coze网页海报bot, element=package.selector("coze自定义背景点击或拖放文件"), simulate=True, move_mouse=False, clicks="click", button="left", keys="null", delay_after="1", anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", timeout="20", _block=("main", 20, "点击元素(web)"))
            xbot_visual.win32.element.input(window="0", element=package.selector("打开文件编辑框"), text=lambda: 列表循环当前项[4], append=False, simulate=True, save_to_clipboard=False, input_type="simulate", contains_hotkey=False, force_ime_ENG=False, send_key_delay="5", focus_timeout="1000", delay_after="1", click_before_input=True, anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", timeout="20", _block=("main", 21, "填写输入框(win)"))
            xbot_visual.win32.element.click(window="0", element=package.selector("打开文件-打开按钮"), clicks="click", button="left", keys="null", delay_after="3", anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", move_mouse=True, simulate=True, timeout="20", _block=("main", 22, "点击元素(win)"))
            web_wait_result = xbot_visual.web.element.wait(browser=coze网页海报bot, element=package.selector("coze自定义背景提交按钮"), state="appear", iswait=True, timeout="20", _block=("main", 23, "等待元素(web)"))
            xbot_visual.web.element.click(browser=coze网页海报bot, element=package.selector("自定义背景板发送按钮"), simulate=True, move_mouse=False, clicks="click", button="left", keys="null", delay_after="1", anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", timeout="20", _block=("main", 24, "点击元素(web)"))
            等待coze发送按钮 = xbot_visual.web.element.wait(browser=coze网页海报bot, element=package.selector("coze发送按钮"), state="appear", iswait=True, timeout="20", _block=("main", 25, "等待元素(web)"))
            xbot_visual.web.element.click(browser=coze网页海报bot, element=package.selector("coze复制按钮"), simulate=True, move_mouse=False, clicks="click", button="left", keys="null", delay_after="1", anchor_type="center", sudoku_part="MiddleCenter", offset_x="0", offset_y="0", timeout="20", _block=("main", 26, "点击元素(web)"))
            图片markdown地址 = xbot_visual.win32.clipboard_get_text(_block=("main", 27, "获取剪切板文本"))
            图片链接地址 = xbot_visual.text.extract_content_from_text(text=图片markdown地址, extract_way="custom", regular_pattern="!\\[[^\\]]*\\]\\(([^)]+)\\)", just_get_first=True, ignore_case=False, _block=("main", 28, "从文本中提取内容"))
            xbot_visual.programing.log(type="info", text=图片链接地址, _block=("main", 29, "打印日志"))
            图片下载名称 = xbot_visual.web.element.download(browser=coze网页海报bot, scene="Url", download_button=None, download_url=lambda: 图片链接地址, file_folder=lambda: ImageSavePath.directory, use_custom_filename=False, file_name="", wait_complete=True, wait_complete_timeout="60", simulate=False, clipboard_input=False, input_type="automatic", wait_dialog_appear_timeout="20", force_ime_ENG=False, send_key_delay="50", focus_timeout="1000", _block=("main", 30, "下载文件"))
            xbot_visual.programing.log(type="info", text=lambda: 图片下载名称, _block=("main", 31, "打印日志"))
        #endloop
        # dir.if_exist
        # dir.makedir
        # programing.log
        # workflow.endif
        # excel.close
    finally:
        pass
